﻿namespace JamSpotApp.Models.Group
{
    public class GroupMemberViewModel
    {
        public Guid UserId { get; set; }
        public string UserName { get; set; }
        public string Instrument { get; set; }
        public string ProfilePicture { get; set; }
    }
}
