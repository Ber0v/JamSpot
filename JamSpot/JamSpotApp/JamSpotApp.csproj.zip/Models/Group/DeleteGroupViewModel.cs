﻿namespace JamSpotApp.Models.Group
{
    public class DeleteGroupViewModel
    {
        public Guid Id { get; set; }

        public string GroupName { get; set; }

        public string Creator { get; set; }
    }
}
