﻿namespace JamSpotApp.Models
{
    public class CreatePostViewModel
    {
    }
}
