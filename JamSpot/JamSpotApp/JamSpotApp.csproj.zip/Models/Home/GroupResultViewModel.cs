﻿namespace JamSpotApp.Models.Home
{
    public class GroupResultViewModel
    {
        public Guid Id { get; set; }
        public string GroupName { get; set; } = string.Empty;
        public string LogoUrl { get; set; } = string.Empty;
    }
}
